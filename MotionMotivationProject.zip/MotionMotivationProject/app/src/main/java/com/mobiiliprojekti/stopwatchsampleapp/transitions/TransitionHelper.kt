package com.mobiiliprojekti.stopwatchsampleapp.transitions

import android.app.Activity
import android.util.Log
import com.google.android.gms.location.ActivityRecognitionClient
import com.google.android.gms.location.ActivityTransition
import com.google.android.gms.location.ActivityTransitionRequest
import com.google.android.gms.location.DetectedActivity

fun Activity.requestActivityTransitionUpdates(){
    val request = ActivityTransitionRequest(getActivitiesToTrack())
    val task = ActivityRecognitionClient(this).requestActivityTransitionUpdates(request,
    TransitionsReceiver.getPendingIntent(this))

    task.run {
        addOnSuccessListener {
            Log.d("TransitionUpdate", "")
        }
        addOnFailureListener {
            Log.d("TransitionUpdate", "")
        }
    }
}

fun Activity.removeActivityTransitionUpdates(){
    val task = ActivityRecognitionClient(this).removeActivityTransitionUpdates(
        TransitionsReceiver.getPendingIntent(this))

    task.run{
        addOnSuccessListener {
            Log.d("TransitionUpdate", "")
        }
        addOnFailureListener {
            Log.d("TransitionUpdate", "")
        }
    }
}

private fun getActivitiesToTrack(): List<ActivityTransition> =
    mutableListOf<ActivityTransition>().apply{
        add(ActivityTransition.Builder()
            .setActivityType(DetectedActivity.STILL)
            .setActivityTransition(ActivityTransition.ACTIVITY_TRANSITION_ENTER)
            .build())
        add(ActivityTransition.Builder()
            .setActivityType(DetectedActivity.STILL)
            .setActivityTransition(ActivityTransition.ACTIVITY_TRANSITION_EXIT)
            .build())
    }