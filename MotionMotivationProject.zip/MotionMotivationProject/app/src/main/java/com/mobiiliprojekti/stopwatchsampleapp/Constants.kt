package com.mobiiliprojekti.stopwatchsampleapp

object Constants {
    const val TIMER_INTERVAL = 1000
}